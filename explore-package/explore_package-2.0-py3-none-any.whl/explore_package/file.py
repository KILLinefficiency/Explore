import __init__ as e
e.invoke("book csv data file.csv")
e.invoke("getbook")
e.invoke("disp b_data->2->4")
